var a = () => 'b';a();
