// Copyright (c) 2019, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

library bar;

part "part_part_of_differently_named_library_lib1.dart";

methodFromLib2() {
  methodFromLib1();
}