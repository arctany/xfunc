// Copyright (c) 2018, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

// Supplement library for
// pkg/front_end_testcases/no_such_method_forwarders/private.dart

library private_module;

abstract class Fisk {
  void _hest();
}

main() {}
