// Copyright (c) 2019, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

import "issue34515_lib1.dart";
import "issue34515_lib2.dart";

void test() {
  ImportedClass(1);
  ImportedClass("a");
}

main() {}
