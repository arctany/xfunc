// Copyright (c) 2016, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.
var color = 'brown';
var thing = 'lazy dog';
var phrase = "The quick $color fox\njumped over the $thing.\n";
var adjacent = '$color$color$color';
var linebreaks = '$color\n$color\n$color';
var other = '$color\n is \n$color';

main() {}
