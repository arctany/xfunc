// Copyright (c) 2018, the Dart project authors. Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE.md file.

import 'deferred_lib.dart' deferred as lib;

main() {}
test() {
  print(lib.C.m());
}
