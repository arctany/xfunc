// Copyright (c) 2018, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

// Companion library to no_such_method_private_setter.dart.

class Bar {
  int _x;
}

void baz(Bar bar) {
  return;
}
