import 'dart-ext:here';
import 'dart-ext:foo/../there';
import 'dart-ext:/usr/local/somewhere';

main() {}
